/*
 * main.cpp
 *
 *  Created on: Jan 25, 2016
 *      Author: rahulpaul
 */

#include <cv.h>
#include <highgui.h>
#include <cxcore.h>
#include <fstream>
#include <iostream>

using namespace cv;
using namespace std;

//Data Structure for storing Camera Location, lense location, axis direction, vertex location
Mat camera_location = Mat(3,1,DataType<double>::type);
Mat axis_direction = Mat(3,1,DataType<double>::type);
Mat lense_location = Mat(3,1,DataType<double>::type);

Mat poly_shape_vertex;

vector<Mat> poly_shape_vertices;//storing vertices of the poly-hedral

map<int,Mat> polyVertex_no_Location_Map;

Mat vertex_image_plane_location;
map<int,Mat> vertex_no_image_plane_location_Map;

//Data Structure for storing connected vertex pair
Mat poly_shape_conn_vertex;
vector<Mat> poly_shape_conn_vertices;

int focal_length = 0;
int total_edges = 0;
int total_vertices = 0;

//method prototypes
void read_config_file(char * fileName);
void calculate_lense_location();
void calculate_params_for_each_object_vertex();
void draw_the_projected_shape();


int main( int argc, char** argv )
{

	//read the configuration file
	char * config_fileName = argv[1];
	read_config_file(config_fileName);

	//find the lense location in world co-ordinates below
	calculate_lense_location();

	//calculate the distance of each vertex from the lense	and project it on image plane
	calculate_params_for_each_object_vertex();

	//draw the points in pixels on the image plane
	draw_the_projected_shape();

	return(0);

}

void calculate_params_for_each_object_vertex()
{
	//calculate the distance (along z-axis of lense)between lense location and the vertex at (1,1,1) in world co-ordinate
		double dist_vertex111_lense_x = lense_location.at<double>(0, 0) - polyVertex_no_Location_Map[5].at<double>(0,0);
		double dist_vertex111_lense_y = lense_location.at<double>(1, 0) - polyVertex_no_Location_Map[5].at<double>(1,0);
		double dist_vertex111_lense_z = lense_location.at<double>(2, 0) - polyVertex_no_Location_Map[5].at<double>(2,0);

		double dist_vertex111_lense = sqrt(dist_vertex111_lense_x * dist_vertex111_lense_x +
											dist_vertex111_lense_y * dist_vertex111_lense_y +
											dist_vertex111_lense_z * dist_vertex111_lense_z);

		double x_vertext111_lense = 0;
		double y_vertext111_lense = 0;

		double x_vertext111_image_plane = ( focal_length * x_vertext111_lense ) / dist_vertex111_lense;
		double y_vertext111_image_plane = ( focal_length * y_vertext111_lense ) / dist_vertex111_lense;

		vertex_image_plane_location = Mat(2,1,DataType<double>::type);
		vertex_image_plane_location.at<double>(0,0) = x_vertext111_image_plane;
		vertex_image_plane_location.at<double>(1,0) = y_vertext111_image_plane;
		vertex_no_image_plane_location_Map[5] = vertex_image_plane_location;

		//calculate the distance (along z-axis of lense)between lense location and the vertex at (0,0,0) in world co-ordinate
		double dist_vertex000_lense_x = lense_location.at<double>(0, 0) - polyVertex_no_Location_Map[1].at<double>(0,0);
		double dist_vertex000_lense_y = lense_location.at<double>(1, 0) - polyVertex_no_Location_Map[1].at<double>(1,0);
		double dist_vertex000_lense_z = lense_location.at<double>(2, 0) - polyVertex_no_Location_Map[1].at<double>(2,0);

		double dist_vertex000_lense = sqrt(dist_vertex000_lense_x * dist_vertex000_lense_x +
											dist_vertex000_lense_y * dist_vertex000_lense_y +
											dist_vertex000_lense_z * dist_vertex000_lense_z);

		double x_vertex000_lense = 0;
		double y_vertex000_lense = 0;

		double x_vertex000_image_plane = ( focal_length * x_vertex000_lense ) / dist_vertex000_lense;
		double y_vertex000_image_plane = ( focal_length * y_vertex000_lense ) / dist_vertex000_lense;

		vertex_image_plane_location = Mat(2,1,DataType<double>::type);
		vertex_image_plane_location.at<double>(0,0) = x_vertex000_image_plane;
		vertex_image_plane_location.at<double>(1,0) = y_vertex000_image_plane;
		vertex_no_image_plane_location_Map[1] = vertex_image_plane_location;

		//calculate the distance (along z-axis of lense)between lense location and the vertex at (1,1,0) in world co-ordinate
		double dist_vertex110_lense_x = lense_location.at<double>(0, 0) - polyVertex_no_Location_Map[5].at<double>(0,0);
		double dist_vertex110_lense_y = lense_location.at<double>(1, 0) - polyVertex_no_Location_Map[5].at<double>(1,0);
		double dist_vertex110_lense_z = lense_location.at<double>(2, 0) - polyVertex_no_Location_Map[5].at<double>(2,0);

		double dist_vertex110_lense = sqrt(dist_vertex110_lense_x * dist_vertex110_lense_x +
											dist_vertex110_lense_y * dist_vertex110_lense_y +
											dist_vertex110_lense_z * dist_vertex110_lense_z);

		double x_vertex110_lense = 0;
		double y_vertex110_lense = -1;

		double x_vertex110_image_plane = ( focal_length * x_vertex110_lense ) / dist_vertex110_lense;
		double y_vertex110_image_plane = ( focal_length * y_vertex110_lense ) / dist_vertex110_lense;

		vertex_image_plane_location = Mat(2,1,DataType<double>::type);
		vertex_image_plane_location.at<double>(0,0) = x_vertex110_image_plane;
		vertex_image_plane_location.at<double>(1,0) = y_vertex110_image_plane;
		vertex_no_image_plane_location_Map[6] = vertex_image_plane_location;

		//calculate the distance (along z-axis of lense)between lense location and the vertex at (0,0,1) in world co-ordinate
		double dist_vertex001_lense_x = lense_location.at<double>(0, 0) - polyVertex_no_Location_Map[1].at<double>(0,0);
		double dist_vertex001_lense_y = lense_location.at<double>(1, 0) - polyVertex_no_Location_Map[1].at<double>(1,0);
		double dist_vertex001_lense_z = lense_location.at<double>(2, 0) - polyVertex_no_Location_Map[1].at<double>(2,0);

		double dist_vertex001_lense = sqrt(dist_vertex001_lense_x * dist_vertex001_lense_x +
											dist_vertex001_lense_y * dist_vertex001_lense_y +
											dist_vertex001_lense_z * dist_vertex001_lense_z);

		double x_vertex001_lense = 0;
		double y_vertex001_lense = 1;

		double x_vertex001_image_plane = ( focal_length * x_vertex001_lense ) / dist_vertex001_lense;
		double y_vertex001_image_plane = ( focal_length * y_vertex001_lense ) / dist_vertex001_lense;

		vertex_image_plane_location = Mat(2,1,DataType<double>::type);
		vertex_image_plane_location.at<double>(0,0) = x_vertex001_image_plane;
		vertex_image_plane_location.at<double>(1,0) = y_vertex001_image_plane;
		vertex_no_image_plane_location_Map[2] = vertex_image_plane_location;

		//calculate the distance (along z-axis of lense)between lense location and the vertex at (0,1,1) in world co-ordinate

		double dist_vertex011_lense = dist_vertex111_lense + (0.5) * sqrt(3);

		double x_vertex011_lense = 0.5 * sqrt(2);
		double y_vertex011_lense = 0.5;

		double x_vertex011_image_plane = ( focal_length * x_vertex011_lense ) / dist_vertex011_lense;
		double y_vertex011_image_plane = ( focal_length * y_vertex011_lense ) / dist_vertex011_lense;

		vertex_image_plane_location = Mat(2,1,DataType<double>::type);
		vertex_image_plane_location.at<double>(0,0) = x_vertex011_image_plane;
		vertex_image_plane_location.at<double>(1,0) = y_vertex011_image_plane;
		vertex_no_image_plane_location_Map[8] = vertex_image_plane_location;


		//calculate the distance (along z-axis of lense)between lense location and the vertex at (1,0,1) in world co-ordinate

		double dist_vertex101_lense = dist_vertex111_lense + (0.5) * sqrt(3);

		double x_vertex101_lense = -0.5 * sqrt(2);
		double y_vertex101_lense = 0.5;

		double x_vertex101_image_plane = ( focal_length * x_vertex101_lense ) / dist_vertex101_lense;
		double y_vertex101_image_plane = ( focal_length * y_vertex101_lense ) / dist_vertex101_lense;

		vertex_image_plane_location = Mat(2,1,DataType<double>::type);
		vertex_image_plane_location.at<double>(0,0) = x_vertex101_image_plane;
		vertex_image_plane_location.at<double>(1,0) = y_vertex101_image_plane;
		vertex_no_image_plane_location_Map[7] = vertex_image_plane_location;


		//calculate the distance (along z-axis of lense)between lense location and the vertex at (0,1,0) in world co-ordinate

		double dist_vertex010_lense = dist_vertex111_lense + (0.5) * sqrt(3);

		double x_vertex010_lense = 0.5 * sqrt(2);
		double y_vertex010_lense = - 0.5;

		double x_vertex010_image_plane = ( focal_length * x_vertex010_lense ) / dist_vertex010_lense;
		double y_vertex010_image_plane = ( focal_length * y_vertex010_lense ) / dist_vertex010_lense;

		vertex_image_plane_location = Mat(2,1,DataType<double>::type);
		vertex_image_plane_location.at<double>(0,0) = x_vertex010_image_plane;
		vertex_image_plane_location.at<double>(1,0) = y_vertex010_image_plane;
		vertex_no_image_plane_location_Map[3] = vertex_image_plane_location;

		//calculate the distance (along z-axis of lense)between lense location and the vertex at (1,0,0) in world co-ordinate

		double dist_vertex100_lense = dist_vertex111_lense + (0.5) * sqrt(3);

		double x_vertex100_lense = - 0.5 * sqrt(2);
		double y_vertex100_lense = - 0.5;

		double x_vertex100_image_plane = ( focal_length * x_vertex100_lense ) / dist_vertex100_lense;
		double y_vertex100_image_plane = ( focal_length * y_vertex100_lense ) / dist_vertex100_lense;

		vertex_image_plane_location = Mat(2,1,DataType<double>::type);
		vertex_image_plane_location.at<double>(0,0) = x_vertex100_image_plane;
		vertex_image_plane_location.at<double>(1,0) = y_vertex100_image_plane;
		vertex_no_image_plane_location_Map[4] = vertex_image_plane_location;
}

void draw_the_projected_shape()
{
	// Create black empty images
	Mat final_image = Mat::zeros( 255, 255, CV_8UC3 );

	int vertices_count = poly_shape_conn_vertices.size();

	for(int counter = 0; counter < vertices_count; counter++ ){

		int vertex1 = poly_shape_conn_vertices[counter].at<double>(0,0);
		int vertex2 = poly_shape_conn_vertices[counter].at<double>(1,0);

		Mat vertex1_mat = vertex_no_image_plane_location_Map[vertex1];
		Mat vertex2_mat = vertex_no_image_plane_location_Map[vertex2];

		//before drawing convert to 256*256 pixel image plane

		// Draw a line
		  line( final_image, Point( (vertex1_mat.at<double>(0,0)*255)+ 128, (vertex1_mat.at<double>(1,0)*255)+128),
				  Point( (vertex2_mat.at<double>(0,0)*255) +128, (vertex2_mat.at<double>(1,0)*255)+128),
				  Scalar( 255, 255, 255 ),  2, 8 );
	}



	imshow("Specific_Image_projection",final_image);
	cv::imwrite("Specific_Projection_Output.jpg",final_image);

	waitKey( 0 );

}

void calculate_lense_location()
{
	//each side of the cube in which the lense center is located
	double lense_cube_each_side = sqrt((focal_length * focal_length)/3.0);

	lense_location.at<double>(0, 0) = camera_location.at<double>(0,0) - lense_cube_each_side;
	lense_location.at<double>(1, 0) = camera_location.at<double>(1,0) - lense_cube_each_side;
	lense_location.at<double>(2, 0) = camera_location.at<double>(2,0) - lense_cube_each_side;
}

void read_config_file(char * config_fileName)
{
	fstream config_fstream;
	config_fstream.open(config_fileName, fstream::in);

	//extract camera location from the config file first
	double currentValue;
	config_fstream >> currentValue;
	camera_location.at<double>(0, 0) = currentValue;

	config_fstream >> currentValue;
	camera_location.at<double>(1, 0) = currentValue;

	config_fstream >> currentValue;
	camera_location.at<double>(2, 0) = currentValue;


	//clean the temporary variable
	currentValue = 0;

	//extract direction location in which camera is looking
	config_fstream >> currentValue;
	axis_direction.at<double>(0, 0) = currentValue;

	config_fstream >> currentValue;
	axis_direction.at<double>(1, 0) = currentValue;

	config_fstream >> currentValue;
	axis_direction.at<double>(2, 0) = currentValue;

	//extract the focal length
	config_fstream >> focal_length;

	//extract the edges
	config_fstream >> total_edges;

	//extract the vertices
	config_fstream >> total_vertices;

	//Read all the vertices
	for(int vertex_counter = 0; vertex_counter < total_vertices; vertex_counter++ )
	{
		//clean the temporary variable
		currentValue = 0;
		poly_shape_vertex = Mat(3,1,DataType<double>::type);

		//extract co-ordinate for each polhedral vertices
		//000
		config_fstream >> currentValue;
		poly_shape_vertex.at<double>(0, 0) = currentValue;

		config_fstream >> currentValue;
		poly_shape_vertex.at<double>(1, 0) = currentValue;

		config_fstream >> currentValue;
		poly_shape_vertex.at<double>(2, 0) = currentValue;

		poly_shape_vertices.push_back(poly_shape_vertex);

		polyVertex_no_Location_Map[vertex_counter + 1] = poly_shape_vertex;
	}

	//read all the pairs of connected vertices

	for(int edge_counter = 0; edge_counter < total_edges; edge_counter++ )
	{
		//clean the temporary variable
		currentValue = 0;
		poly_shape_conn_vertex = Mat(2,1,DataType<double>::type);

		//first pair
		config_fstream >> currentValue;
		poly_shape_conn_vertex.at<double>(0, 0) = currentValue;

		config_fstream >> currentValue;
		poly_shape_conn_vertex.at<double>(1, 0) = currentValue;

		poly_shape_conn_vertices.push_back(poly_shape_conn_vertex);
	}
}







